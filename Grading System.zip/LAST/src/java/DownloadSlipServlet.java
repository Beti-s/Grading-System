import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

// Map the servlet to the desired URL pattern
@WebServlet("/DownloadSlipServlet")
public class DownloadSlipServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String studentId = request.getParameter("studentId");
        String courseId = request.getParameter("courseId");

        if (studentId == null || courseId == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing studentId or courseId");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WEB", "root", "Betty@22292229");

            String detailsQuery = "SELECT s.full_name AS student_name, c.course_name, t.full_name AS teacher_name, g.mid_exam, g.project, g.final_exam " +
                                  "FROM Students s " +
                                  "INNER JOIN Student_Courses sc ON s.student_id = sc.student_id " +
                                  "INNER JOIN Courses c ON sc.course_id = c.course_id " +
                                  "INNER JOIN TeacherAssignments ta ON c.course_id = ta.course_id " +
                                  "INNER JOIN Teachers t ON ta.teacher_id = t.teacher_id " +
                                  "LEFT JOIN Grades g ON s.student_id = g.student_id AND c.course_id = g.course_id " +
                                  "WHERE s.student_id = ? AND c.course_id = ?";
            stmt = conn.prepareStatement(detailsQuery);
            stmt.setString(1, studentId);
            stmt.setString(2, courseId);
            rs = stmt.executeQuery();

            if (rs.next()) {
                String studentName = rs.getString("student_name");
                String courseName = rs.getString("course_name");
                String teacherName = rs.getString("teacher_name");
                String midExam = rs.getString("mid_exam") != null ? rs.getString("mid_exam") : "N/A";
                String project = rs.getString("project") != null ? rs.getString("project") : "N/A";
                String finalExam = rs.getString("final_exam") != null ? rs.getString("final_exam") : "N/A";

                // Configure response for PDF download
                response.setContentType("application/pdf");
                response.setHeader("Content-Disposition", "attachment;filename=CourseDetailsSlip.pdf");

                // Create PDF document
                Document document = new Document();
                PdfWriter.getInstance(document, response.getOutputStream());
                document.open();

                // Add content to PDF
                document.add(new Paragraph("Course Details Slip\n\n", FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16)));
                document.add(new Paragraph("Student Name: " + studentName));
                document.add(new Paragraph("Student ID: " + studentId));
                document.add(new Paragraph("Course Name: " + courseName));
                document.add(new Paragraph("Teacher Name: " + teacherName));
                document.add(new Paragraph("Mid Exam: " + midExam));
                document.add(new Paragraph("Project: " + project));
                document.add(new Paragraph("Final Exam: " + finalExam));

                document.close();
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "No details found for the given student and course");
            }

        } catch (DocumentException | IOException | ClassNotFoundException | SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating slip");
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                // Handle exception
            }
        }
    }
}
